package com.infy.customer.exception;

public class AadharNumberInvalidException extends Exception{

	public AadharNumberInvalidException(String message) {
		super(message);
	}
	
}