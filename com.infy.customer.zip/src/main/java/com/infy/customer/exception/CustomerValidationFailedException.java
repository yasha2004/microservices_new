package com.infy.customer.exception;

public class CustomerValidationFailedException extends Exception{

	public CustomerValidationFailedException(String message) {
		super(message);
	}
	
}
