package com.infy.customer.exception;

public class DateOfBirthInvalidException extends Exception {

	public DateOfBirthInvalidException(String message) {
		super(message);
	}
	
}