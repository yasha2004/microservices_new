package com.infy.customer.exception;

public class EmailAddressInvalidException extends Exception {

	public EmailAddressInvalidException(String message) {
		super(message);
	}
	
}
