package com.infy.customer.exception;

public class FirstNameLastNameInvalidException extends Exception {

	public FirstNameLastNameInvalidException(String message) {
		super(message);
	}
	
}
