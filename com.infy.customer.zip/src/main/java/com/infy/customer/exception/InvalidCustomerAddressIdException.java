package com.infy.customer.exception;

public class InvalidCustomerAddressIdException extends Exception {

	public InvalidCustomerAddressIdException(String message) {
		super(message);
	}
	
}
