package com.infy.customer.exception;

public class InvalidCustomerAddressSimDetailsException extends Exception {

	public InvalidCustomerAddressSimDetailsException(String message) {
		super(message);
	}
	
}
