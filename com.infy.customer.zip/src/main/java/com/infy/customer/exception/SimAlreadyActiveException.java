package com.infy.customer.exception;

public class SimAlreadyActiveException extends Exception {

	public SimAlreadyActiveException(String message) {
		super(message);
	}
	
}
