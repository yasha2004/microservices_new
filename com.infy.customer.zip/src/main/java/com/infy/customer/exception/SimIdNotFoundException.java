package com.infy.customer.exception;

public class SimIdNotFoundException extends Exception {

	public SimIdNotFoundException(String message) {
		super(message);
	}
	
}
