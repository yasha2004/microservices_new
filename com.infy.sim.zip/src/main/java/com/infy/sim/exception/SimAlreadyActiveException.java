package com.infy.sim.exception;

public class SimAlreadyActiveException extends Exception {

	public SimAlreadyActiveException(String message) {
		super(message);
	}
	
}
