package com.infy.sim.exception;

public class SimIdNotFoundException extends Exception {

	public SimIdNotFoundException(String message) {
		super(message);
	}
	
}
