package com.infy.sim.exception;

public class SimOfferNotFoundException extends Exception {

	public SimOfferNotFoundException(String message) {
		super(message);
	}
	
}
