package com.infy.sim.exception;

public class SimServiceNumberInvalidException extends Exception{

	public SimServiceNumberInvalidException(String message) {
		super(message);
	}
	
}

